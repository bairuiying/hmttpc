<template>
  <div class='nx'>
      我感动的快哭了, 我们竟然手写了一个脚手架
      {{ name }}
    <input v-model="name" /> 
  </div>
</template>

<script>
export default {
  data () {
      return {
          name: '张三'
      }
  }
}
</script>

<style>
.nx {
    color:red
}
</style>