// import $ from 'jquery'
// import './styles/index.css'
// import './styles/second.less'
// let liHtml = []
// for (var i = 0; i < 100; i++) {
//     liHtml.push(`<li >我是第${i + 1}个里标签,你看我的颜色!!!!</li>`)
// }
// let bossName = '陈浩南'
// let strTemplate = `
//    <li>我是老大${bossName},都听我的!!!</li>
// `
// let boss2 = '山鸡'
// let  template  = `<li>我是老二${boss2},都听老大的</li>`
// let newList = [strTemplate,template,...liHtml]  // ES6解构赋值
// $('#app').append(`<ul>${newList.join("")}</ul>`)
// $("li:even").css({ background: 'pink', color: '#fff', fontSize: '30px' })
import Vue  from 'vue'
import App from './App.vue'
new Vue({
   render: h => h(App)
}).$mount("#app") // 渲染到页面上