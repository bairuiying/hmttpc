/*****
 *  webpack的配置文件
 * 
 * ***/
var path = require('path') // 路径管理模块
var HtmlPlugin = require('html-webpack-plugin') // 引入安装的包 它的功能是 帮助我们自动引入 打包的文件 然后拷贝到输出目录
var  VueLoaderPlugin  = require('vue-loader/lib/plugin') // 这是vue-loader要求如果使用vue-loader 必须 伴生 vueloaderplugin
// commonjs 的导出
module.exports  = {
    // webpack 的配置选项
    mode: 'development', // production (生产环境) development(开发环境)
    // 配置webpack打包的入口
    entry: path.resolve('./src/main.js'),  // 表示一个打包文件的入口地址 path.resolve() 会生成一个绝对路径
    output: {
        // output 配置 打包输出的信息
        path: path.resolve('./build'), // 配置输出的目录
        filename: 'app.js' // 配置输出的文件名
    },
    // 插件配置在webpack 的 plugins中
    plugins: [
        // 实例化插件,传入构造参数
        new HtmlPlugin({
            // template 的意思是模板的意思  表示 从哪个目录里面 找到要拷贝的模板 然后自动引入文件
            template: path.resolve('./public/index.html') // 找到模板文件
        }),
        new VueLoaderPlugin() // 配合 vue-loader使用
    ],
    // 配置webpackdevserver选项
    devServer: {
        // 配置 webpack-dev-server的选项
        host: '127.0.0.1',  // 配置启动ip地址
        port: 10088,  // 配置端口
        open: true  // 配置是否自动打开浏览器
    },
    module: {
        // 配置所有的 处理规则  什么文件用什么loader处理
        rules: [{
            // 处理css文件
            test: /\.css$/,    // 正则表达式 匹配所有的css文件
            // loader的顺序是非常严格的 先写谁  表示最后执行谁
            // 执行顺序实际上是从右向左
            use: ['style-loader','css-loader']  // use是一个数组 也可以换成loaders style-loader  css-loader
            // css-loader 的功能是 负责 把css文件变成 js文件的一个代码块
            // style-loader 的功能是 负责 把js的代码块变成 html 页面中的一个style标签
        },{
            test: /\.(png|gif|jpg|jpeg)$/i,  // 匹配图片文件
            // use 可以是字符串数组 也可是 数组对象
            use: [{
                loader: 'url-loader',  // url-loader 的作用是 把文件 转化成base64字符串 写入到app.js中
                // 超过 阈值 会自动调用filer-loader方法 不会自己写
                options: {
                    // 作为url-loader 配置参数
                    // 8kb 超过图片过8kb 就直接拷贝 如果不超过 就生成base64字符串 写入到 app.js中
                    limit: 8192,  // 阈值 相当于水位的意思 如果超过了水位 就自动采用file-loader的方式 拷贝文件
                    // 如果没有超过水位, 就按照之前的方式 转成base 64
                    outputPath: 'images' // 设置物理文件的目录
                }
                // 如果用url-loader 可以省去一次请求 如果图片过大  app.js 也会过大
                // url-loader 和 file-loader都可以解决图片问题 但是我们一般要让他们两个配合使用
                
            }]
            // loaders: ['file-loader'] // 只写一个file-loader
            // file-loader 的解决方案是 把对应的文件 拷贝到输出目录中 而且还还改了名字
        },{
            test: /\.less$/, // 匹配less文件
            loaders: ['style-loader','css-loader','less-loader'] // loader  less文件没办法解析 less-css  css -js  js  => style
            
        },{
            test: /\.js$/,
            exclude: /node_modules/,  // 排除目录
            loaders: ['babel-loader']  // es6转es5
        },{
            test: /\.vue$/,  // 匹配.vue文件 
            loaders: ['vue-loader'] // 用vue-loader来处理
        }]
    }
}


//  webpack.config 文件一旦改动 就需要重新启动服务 才能生效