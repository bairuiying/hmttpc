module.exports = {
    presets: ['@babel/preset-env']  // 包含了众多es6转es5插件的preset
}